#!/bin/bash
# ChocoEdit installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the ChocoEdit error list:"
  echo "  https://github.com/jonpikereally/ChocoEdit/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing ChocoEdit…"
mkdir -p ~/Applications || fail CE-601 "Couldn't create ~/Applications."
rm -rf ~/Applications/ChocoEdit.app
ditto --norsrc ChocoEdit.app ~/Applications/ChocoEdit.app \
  || fail CE-601 "Couldn't copy ChocoEdit into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/ChocoEdit.app 2>/dev/null
codesign --force --sign - ~/Applications/ChocoEdit.app 2>/dev/null \
  || fail CE-602 "Couldn't sign ChocoEdit for this Mac."
open ~/Applications/ChocoEdit.app \
  || fail CE-603 "ChocoEdit was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Plug in your Chocolate Plus with USB, quit CubeSuite, and click Read from Pedal."
