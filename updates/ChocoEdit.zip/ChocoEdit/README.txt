ChocoEdit v0.1 — an editor for the M-VAVE Chocolate Plus MIDI foot controller (macOS 13+)
https://github.com/jonpikereally/ChocoEdit

INSTALL
1. Double-click "Install ChocoEdit.command".
   If macOS blocks it: right-click it, choose Open, then Open again.

USE
1. Plug the pedal in with a USB-C data cable and switch it on. Quit CubeSuite.
2. Click Read from Pedal. Pick a group, click a switch, edit its messages.
3. Click Write to Pedal. ChocoEdit backs up the pedal's current settings to
   ~/Documents/ChocoEdit Backups first, writes only what changed, and reads it
   back to check.

ChocoEdit isn't made or supported by M-VAVE. It speaks the same protocol as
their CubeSuite app.

PRIVACY
ChocoEdit talks only to the pedal over MIDI. No accounts, no analytics. The
only thing it fetches from the internet is a small version file from the
GitHub repo above, to see whether an update exists.
